import express from 'express'
import cors from 'cors'
import compression from 'compression'
import type { ErrorRequestHandler } from 'express'
import { env } from './config/env.js'
import { prisma } from './utils/prisma.js'
import authRoutes from './routes/auth.routes.js'
import configRoutes from './routes/config.routes.js'
import conversationRoutes from './routes/conversation.routes.js'
import apikeyRoutes from './routes/apikey.routes.js'
import balanceRoutes from './routes/balance.routes.js'
import marketRoutes from './routes/market.routes.js'
import timelineRoutes from './routes/timeline.routes.js'
import statsRoutes from './routes/stats.routes.js'
import alpacaRoutes from './routes/alpaca.routes.js'
import paymentRoutes from './routes/payment.routes.js'
import adminRoutes from './routes/admin.routes.js'
import searchRoutes from './routes/search.routes.js'
import chatRoutes from './routes/chat.routes.js'
import tokenRoutes from './routes/token.routes.js'
import v1Routes from './routes/v1.routes.js'
import subscriptionRoutes from './routes/subscription.routes.js'
import summaryRoutes from './routes/summary.routes.js'
import folderRoutes from './routes/folder.routes.js'
import referralRoutes from './routes/referral.routes.js'
import oauth2Routes from './routes/oauth2.routes.js'
import adsRoutes from './routes/ads.routes.js'
import { asyncHandler } from './utils/async.js'
import { recordAdWatch, type CsjCallbackPayload } from './services/ads.js'

const app = express()

app.use(cors({ origin: [env.frontendOrigin, env.adminOrigin], credentials: true }))
app.use(compression())  // gzip 压缩：20MB JSON → ~1-2MB，大幅减少传输时间
app.use(express.json({ limit: '50mb' }))

app.get('/api/health', (_req, res) => res.json({ ok: true }))

// ═══════════ 穿山甲激励视频服务端回调（根路径，注意 webhoook 三连 o 拼写按后台原样） ═══════════
// 穿山甲默认 GET；同时接受 POST 兜底。返回 {"isValid": true/false}。
const handleCsjCallback = asyncHandler(async (req, res) => {
  const q = req.query || {}
  const b = (req.body || {}) as Record<string, unknown>
  const payload: CsjCallbackPayload = {
    user_id: q.user_id ?? b.user_id,
    trans_id: q.trans_id ?? b.trans_id,
    reward_name: q.reward_name ?? b.reward_name,
    reward_amount: q.reward_amount ?? b.reward_amount,
    extra: q.extra ?? b.extra,
    sign: q.sign ?? b.sign,
  }
  const result = await recordAdWatch(payload)
  if (!result.isValid && result.reason) {
    console.warn(`[ads/webhook] 拒绝: ${result.reason}`)
  }
  res.json({ isValid: result.isValid })
})
app.get('/webhoook/verify', handleCsjCallback)
app.post('/webhoook/verify', handleCsjCallback)

app.use('/api/auth', authRoutes)
app.use('/api/configs', configRoutes)
app.use('/api/conversations', conversationRoutes)
app.use('/api/apikeys', apikeyRoutes)
app.use('/api/balance', balanceRoutes)
app.use('/api/market', marketRoutes)
app.use('/api/timeline', timelineRoutes)
app.use('/api/stats', statsRoutes)
app.use('/api/alpaca', alpacaRoutes)
app.use('/api/payment', paymentRoutes)
app.use('/api/admin', adminRoutes)
app.use('/api/search', searchRoutes)
app.use('/api/chat', chatRoutes)
app.use('/api/tokens', tokenRoutes)
app.use('/api/v1', v1Routes)
app.use('/api/subscription', subscriptionRoutes)
app.use('/api/summaries', summaryRoutes)
app.use('/api/folders', folderRoutes)
app.use('/api/referral', referralRoutes)
app.use('/api/oauth', oauth2Routes)
app.use('/api/ads', adsRoutes)

const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  // multer 文件大小错误
  if (err?.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: '压缩包过大（>200MB）' })
  }
  console.error('[error]', err?.message || err)
  res.status(err?.status || 500).json({ error: err?.message || '服务器内部错误' })
}
app.use(errorHandler)

async function seed() {
  const count = await prisma.appMarketEntry.count()
  if (count === 0) {
    await prisma.appMarketEntry.createMany({
      data: [
        { name: 'Deepseek 官网', url: 'https://www.deepseek.com', description: 'Deepseek 官方网站', category: 'official' },
        { name: 'Deepseek API 平台', url: 'https://platform.deepseek.com', description: 'Deepseek API 开放平台，可获取 API Key', category: 'official' },
      ],
    })
    console.log('[seed] 已初始化应用市场占位数据')
  }
  // 内置 OAuth2 公共客户端（PKCE，无 secret）
  const mobileClient = await prisma.oAuthClient.findUnique({ where: { clientId: 'dstk-mobile-app' } })
  if (!mobileClient) {
    await prisma.oAuthClient.create({
      data: {
        clientId: 'dstk-mobile-app',
        name: 'DsToolKit Mobile App',
        isPublic: true,
        redirectUris: ['dstoolkit://oauth-callback'],
        scopes: ['read:conversations', 'search', 'profile', 'offline_access'],
      },
    })
    console.log('[seed] 已创建 OAuth 客户端 dstk-mobile-app')
  }
}

const server = app.listen(env.port, async () => {
  console.log(`[dstoolkit] backend running on http://localhost:${env.port}`)
  if (env.meiliEnabled) {
    console.log(`[dstoolkit] Meilisearch enabled at ${env.meiliHost}`)
  } else {
    console.log('[dstoolkit] Meilisearch disabled (MEILISEARCH_HOST empty) - cloud_v1 search will gracefully degrade)')
  }
  try {
    await seed()
  } catch (e) {
    console.error('[seed] 失败', e)
  }
})

async function shutdown() {
  console.log('\n[dstoolkit] closing...')
  await prisma.$disconnect()
  server.close(() => process.exit(0))
}
process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)

export { app, server }
